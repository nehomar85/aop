<!-- Modal -->
<div class="modal fade" id="casosImp" tabindex="-1" role="dialog" data-backdrop="false" style="background-color:rgba(0,0,0,0.5);">
  <div class="modal-dialog modal-lg" role="document">
	<div class="modal-content">
	  <div class="modal-header">
		<h5 class="modal-title col-11 text-center">Casos Asociados a la Implementación</h5>
		<button type="button" class="close col-1" data-dismiss="modal" aria-label="Close">
		  <span aria-hidden="true">&times;</span>
		</button>
	  </div>
	  <div class="modal-body">
		<div class="container-fluid">
		
		  <div class="form-group row">
			<div class="col-sm-2">
			  <input class="form-control form-control-sm" id="eidIMP" name="eidIMP" disabled></input>
			</div>
			<div class="col-sm-10">
			  <input class="form-control form-control-sm" id="eDescripcion" name="eDescripcion" disabled></input>
			</div>
		  </div>
		  
		  <div class='row'>
			<div class='col-xs-12 col-sm-6'></br>
			  <div><Label>Casos No Resueltos</Label></div>
			  <div id="casosAbiertos"></div>
			</div>
			<div class='col-xs-12 col-sm-6'></br>
			  <div><Label>Casos Resueltos</Label></div>
			  <div id='casosResueltos'></div>
			</div>
		  </div>

		</div>
	  </div>
	</div>
  </div>
</div>
<script>
$(document).ready(function(){
	$(document).on('click', '.UpdIMPCaso', function(){
		var id=$(this).val();
		var idcasoIMP=$('#AbiertoIMPCaso'+id).text();
		var IMPPpal=$('#IMPPpal'+id).text();
		var FechaIMPCaso=$('#FechaIMPCaso'+id).text();
		var MotivoIMPCaso=$('#MotivoIMPCaso'+id).text();
		var PrioridadIMPCaso=$('#PrioridadIMPCaso'+id).text();
		var EscaladoIMPCaso=$('#EscaladoIMPCaso'+id).text();
		var DescripcionIMPCaso=$('#DescripcionIMPCaso'+id).text();
		var ClaseIMPCaso=$('#ClaseIMPCaso'+id).text();
		var CategoriaIMPCaso=$('#CategoriaIMPCaso'+id).text();
		var AsignadoIMPCaso=$('#AsignadoIMPCaso'+id).text();
		var RegistroTrabIMPCaso=$('#RegistroTrabIMPCaso'+id).text();
		var CausaRaizIMPCaso=$('#CausaRaizIMPCaso'+id).text();
		var EstadoIMPCaso=$('#EstadoIMPCaso'+id).text();
		var LastUpdIMPCaso=$('#LastUpdIMPCaso'+id).text();
		
		$('#ModalAbiertoIMPCaso').modal('show');
		
		$('#eidIMPcasoUpd').val(idcasoIMP);
		$('#eidIMP_asoc').val(IMPPpal);
		$('#efechainicioIMPcaso').val(FechaIMPCaso);
		$('#eMotivoImplementaIMPcaso').val(MotivoIMPCaso);
		$('#eprioridadIMPcaso').val(PrioridadIMPCaso);
		$('#emedioIMPcaso').val(EscaladoIMPCaso);
		$('#edescripcionIMPcaso').val(DescripcionIMPCaso);
		$('#eclase3').val(ClaseIMPCaso);
		$('#ecategoria3').val(CategoriaIMPCaso);
		$('#eusuario_asignadoIMPcaso').val(AsignadoIMPCaso);
		$('#eRegistroTrabajoIMPCaso').val(RegistroTrabIMPCaso);
		$('#eCausalIMPCaso').val(CausaRaizIMPCaso);
		$('#eEstatusIMPCaso').val(EstadoIMPCaso);
		$('#eLastUpdIMPCaso').val(LastUpdIMPCaso);
	});
});
</script>
<script>
$(document).ready(function(){
	$(document).on('click', '.DetIMPCaso', function(){
		var id=$(this).val();
		var idcasoIMP=$('#AbiertoIMPCaso'+id).text();
		var IMPPpal=$('#IMPPpal'+id).text();
		var FechaIMPCaso=$('#FechaIMPCaso'+id).text();
		var MotivoIMPCaso=$('#MotivoIMPCaso'+id).text();
		var PrioridadIMPCaso=$('#PrioridadIMPCaso'+id).text();
		var EscaladoIMPCaso=$('#EscaladoIMPCaso'+id).text();
		var DescripcionIMPCaso=$('#DescripcionIMPCaso'+id).text();
		var ClaseIMPCaso=$('#ClaseIMPCaso'+id).text();
		var CategoriaIMPCaso=$('#CategoriaIMPCaso'+id).text();
		var AsignadoIMPCaso=$('#AsignadoIMPCaso'+id).text();
		var RegistroTrabIMPCaso=$('#RegistroTrabIMPCaso'+id).text();
		var CausaRaizIMPCaso=$('#CausaRaizIMPCaso'+id).text();
		var EstadoIMPCaso=$('#EstadoIMPCaso'+id).text();
		var SolucionIMPCaso=$('#SolucionIMPCaso'+id).text();
		var HorasSolIMPCaso=$('#HorasSolIMPCaso'+id).text();
		
		$('#ModalDetalleIMPCaso').modal('show');
		
		$('#didIMPcasoUpd').val(idcasoIMP);
		$('#didIMP_asoc').val(IMPPpal);
		$('#dfechainicioIMPcaso').val(FechaIMPCaso);
		$('#dMotivoImplementaIMPcaso').val(MotivoIMPCaso);
		$('#dprioridadIMPcaso').val(PrioridadIMPCaso);
		$('#dmedioIMPcaso').val(EscaladoIMPCaso);
		$('#ddescripcionIMPcaso').val(DescripcionIMPCaso);
		$('#dclase3').val(ClaseIMPCaso);
		$('#dcategoria3').val(CategoriaIMPCaso);
		$('#dusuario_asignadoIMPcaso').val(AsignadoIMPCaso);
		$('#dRegistroTrabajoIMPCaso').val(RegistroTrabIMPCaso);
		$('#dCausalIMPCaso').val(CausaRaizIMPCaso);
		$('#dEstatusIMPCaso').val(EstadoIMPCaso);
		$('#dSolucionIMPCaso').val(SolucionIMPCaso);
		$('#dHorasSolIMPCaso').val(HorasSolIMPCaso);
	});
});
</script>