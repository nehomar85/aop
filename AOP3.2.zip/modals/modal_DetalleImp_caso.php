<!-- Modal -->
<div class="modal fade" id="ModalDetalleIMPCaso" tabindex="-1" role="dialog" data-backdrop="false" style="background-color:rgba(0,0,0,0.5);z-index:1240;"> 
  <div class="modal-dialog" role="document">
 	<div class="modal-content">
	  <div class="modal-header">
		<h5 class="modal-title col-11 text-center">Detalle Caso IMP</h5>
		<button type="button" class="close col-1" data-dismiss="modal" aria-label="Close">
		  <span aria-hidden="true">&times;</span>
		</button>
	  </div>
	  <div class="modal-body">
		<div class="container-fluid">
		  <form role="form" id="formularioIMPcasoDet" method="post">
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="idIMPcasoUpd">Caso-IMP #</label>
				<div class="col-sm-9" id="divIdImp">
				  <input type="text" class="form-control form-control-sm" id="didIMPcasoUpd" readonly>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="idIMP_asocUpd">IMP Asociada</label>
				<div class="col-sm-9" id="divIdImp">
				  <input type="text" class="form-control form-control-sm" id="didIMP_asoc" readonly>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="fechainicioIMPcasoUpd">Fecha Caso</label>
				<div class="col-sm-9" id="divIdImp">
				  <input type="text" class="form-control form-control-sm" id="dfechainicioIMPcaso" readonly>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="motivoImplementaIMPcasoUpd">Motivo</label>
				<div class="col-sm-9">
				  <input class="form-control form-control-sm" id="dMotivoImplementaIMPcaso" readonly>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="prioridadIMPcasoUPd">Prioridad</label>
				<div class="col-sm-9">
				  <input class="form-control form-control-sm" id="dprioridadIMPcaso" readonly>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="medioIMPcasoUpd">Escalado Por</label>
				<div class="col-sm-9">
				  <input class="form-control form-control-sm" id="dmedioIMPcaso" readonly>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="descripcionIMPcasoUpd">Descripción</label>
				<div class="col-sm-9">
				  <textarea class="form-control form-control-sm" id="ddescripcionIMPcaso" readonly></textarea>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="clase">Clase</label>
				<div class="col-sm-9">
				  <input class="form-control form-control-sm" id="dclase3" readonly>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label">Categoría</label>
				<div class="col-sm-9">
				  <input class="form-control form-control-sm" id="dcategoria3" readonly>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="usuario_asignadoIMPcasoUpd">Asignado A</label>
				<div class="col-sm-9">
				  <input class="form-control form-control-sm" id="dusuario_asignadoIMPcaso" readonly>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="RegistroTrabajoIMPCasoUpd">Registro de Trabajo</label>
				<div class="col-sm-9">
				  <Textarea class="form-control form-control-sm" id="dRegistroTrabajoIMPCaso" readonly></Textarea>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="CausalIMPCasoUpd">Causa Raíz</label>
				<div class="col-sm-9">
				  <input class="form-control form-control-sm" id="dCausalIMPCaso" readonly>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="EstatusIMPCasoUpd">Estatus</label>
				<div class="col-sm-9">
				  <input class="form-control form-control-sm" id="dEstatusIMPCaso" readonly>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="FechaLastUpdIMPCaso">Fecha Solución</label>
				<div class="col-sm-9" id="divIdImp">
				  <input class="form-control form-control-sm" id="dSolucionIMPCaso" readonly>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="FechaLastUpdIMPCaso">Horas Solución</label>
				<div class="col-sm-9" id="divIdImp">
				  <input class="form-control form-control-sm text-danger" id="dHorasSolIMPCaso" readonly>
				</div>
			  </div>
			  <div class="ln_solid"></div>
			  <div class="modal-footer justify-content-between">
				<button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
			  </div>
		  </form>
		</div>
	  </div>
 	</div>
  </div>
</div>