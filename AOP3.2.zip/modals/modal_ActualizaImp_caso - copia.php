<?php include_once('tipificaciones/ConsultasOperaciones.php');?>
<!-- Modal -->
<div class="modal fade" id="ModalAbiertoIMPCaso" tabindex="-1" role="dialog" data-backdrop="false" style="background-color:rgba(0,0,0,0.5);z-index:1240;"> 
  <div class="modal-dialog" role="document">
 	<div class="modal-content">
	  <div class="modal-header">
		<h5 class="modal-title col-11 text-center">Actualizar Caso IMP</h5>
		<button type="button" class="close col-1" data-dismiss="modal" aria-label="Close">
		  <span aria-hidden="true">&times;</span>
		</button>
	  </div>
	  <div class="modal-body">
		<div class="container-fluid">
		  <form role="form" id="formularioIMPcasoUpd" method="post">
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="idIMPcasoUpd">Caso-IMP #</label>
				<div class="col-sm-9" id="divIdImp">
				  <input type="text" class="form-control form-control-sm" id="eidIMPcasoUpd" name="eidIMPcasoUpd" required readonly>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="idIMP_asocUpd">IMP Asociada</label>
				<div class="col-sm-9" id="divIdImp">
				  <input type="text" class="form-control form-control-sm" id="eidIMP_asoc" name="eidIMP_asoc" required readonly>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="fechainicioIMPcasoUpd">Fecha Caso</label>
				<div class="col-sm-9" id="divIdImp">
				  <input type="text" class="form-control form-control-sm" id="efechainicioIMPcaso" name="efechainicioIMPcaso" required readonly>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="motivoImplementaIMPcasoUpd">Motivo</label>
				<div class="col-sm-9">
				  <select class="form-control form-control-sm" id="eMotivoImplementaIMPcaso" name="eMotivoImplementaIMPcaso" required>
					<option value="" selected></option>
					<option value="Estabilizacion Incidente">Estabilización Incidente</option>
					<option value="Estabilizacion Solicitud">Estabilización Solicitud</option>
				  </select>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="prioridadIMPcasoUPd">Prioridad</label>
				<div class="col-sm-9">
				  <select class="form-control form-control-sm" id="eprioridadIMPcaso" name="eprioridadIMPcaso" required><?php echo $Prioridad; ?></select>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="medioIMPcasoUpd">Escalado Por</label>
				<div class="col-sm-9">
				  <select class="form-control form-control-sm" id="emedioIMPcaso" name="emedioIMPcaso" required><?php echo $Medio_imp; ?></select>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="descripcionIMPcasoUpd">Descripción</label>
				<div class="col-sm-9">
				  <textarea class="form-control form-control-sm" id="edescripcionIMPcaso" name="edescripcionIMPcaso" required></textarea>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="clase">Clase</label>
				<div class="col-sm-9">
				  <select id="eclase3" name="eclase3" class="form-control form-control-sm" required><?php echo $Clase; ?></select>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label">Categoría</label>
				<div class="col-sm-9">
				  <select id="ecategoria3" name="ecategoria3" class="form-control form-control-sm" ><?php echo $Categoria; ?></select>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="usuario_asignadoIMPcasoUpd">Asignado A</label>
				<div class="col-sm-9">
				  <select class="form-control form-control-sm" id="eusuario_asignadoIMPcaso" name="eusuario_asignadoIMPcaso" required><?php echo $Grupo; ?></select>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="RegistroTrabajoIMPCasoUpd">Registro de Trabajo</label>
				<div class="col-sm-9">
				  <Textarea class="form-control form-control-sm" id="eRegistroTrabajoIMPCaso" name="eRegistroTrabajoIMPCaso" required></Textarea>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="CausalIMPCasoUpd">Causa Raíz</label>
				<div class="col-sm-9">
				  <select class="form-control form-control-sm" id="eCausalIMPCaso" name="eCausalIMPCaso" required><?php echo $CausaRaiz; ?></select>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="EstatusIMPCasoUpd">Estatus</label>
				<div class="col-sm-9">
				  <select class="form-control form-control-sm" id="eEstatusIMPCaso" name="eEstatusIMPCaso" onChange="validaEstadoIMP(this)" required><?php echo $Estatus; ?></select>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="FechaLastUpdIMPCaso">Último Update</label>
				<div class="col-sm-9" id="divIdImp">
				  <input type="text" class="form-control form-control-sm text-danger" id="eLastUpdIMPCaso" name="eLastUpdIMPCaso" required readonly>
				</div>
			  </div>
			  <div class="form-group row">
				<label class="col-sm-3 col-form-label" for="FechaUpdIMPcaso">Fecha Cambio</label>
				<div class="col-sm-9">
				  <input type="datetime-local" id="eFechaUpdIMPcaso" name="eFechaUpdIMPcaso" class="form-control form-control-sm" required>
				</div>
			  </div>
			  <div class="ln_solid"></div>
			  <div class="modal-footer justify-content-between">
				<button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
				<button type="submit" class="btn btn-primary" id="UpdIMP_caso">Actualizar</button>
			  </div>
			  <input id="usuario_logIMPcasoUpd" name="usuario_logIMPcasoUpd" value="<?php echo $_SESSION['nombre'] . " " . $_SESSION['apellido']?>" hidden>
		  </form>
		</div>
	  </div>
 	</div>
  </div>
</div>
<script>
$(document).ready(function(){
	$("#eclase3").change(function(){
		$.ajax({
			url:"tipificaciones/TipificaCat_caso",
			type: "POST",
			data:"idclase="+$("#eclase3").val(),
			success: function(clase){
				$("#ecategoria3").html(clase);
			}
		})
	});
});
</script>
<script>
$(document).ready(function() {
  $("#ModalAbiertoIMPCaso").submit(function(h){
	var ok = true;
	var msg = '';
	var redir = 1;
	var idIMPCasoUpd = $("#eidIMPcasoUpd").val();
	var fechaLastUpdIMPCaso = $("#eLastUpdIMPCaso").val();
	var fechaUpdIMPCaso = $("#eFechaUpdIMPcaso").val();
	var estatusIMPCaso = $("#eEstatusIMPCaso").val();
	var estatusFinal = '';
	
	if(estatusIMPCaso=='Resuelto' || estatusIMPCaso=='Cerrado'){
		estatusFinal = estatusIMPCaso;
	}else{
		estatusFinal = 'actualizado';
	}
	
	if(Date.parse(fechaUpdIMPCaso)<Date.parse(fechaLastUpdIMPCaso)){
	  msg = 'La Fecha de Cambio debe ser mayor al último update';
	  redir = 0;
	  ok = false;
	}else{
	  h.preventDefault();
	  $.ajax({
	    url: "controllers/ActualizarImpCaso",
	    method: "post",
	    data: $("form").serialize(),
	    dataType: "text",
	    success: function(impCasoUpd){
			//Actualizada
	    }
	  });
	  msg = 'Caso de implementación '+idIMPCasoUpd+' correctamente '+estatusFinal;
	  redir = 1;
	  ok = false;
	}
	
	if(ok == false){
	  if(redir == 0){
		alert(msg);
	  }else{
		alert(msg);
		
		$('#ModalAbiertoIMPCaso').modal('hide');
		var idIMP=$('#eidIMP_asoc').val();
		$('#casosImp').modal('show');
		$.ajax({
			type: "GET",
			url: 'tablas/historico_Imp_casos_asoc',
			idIMP:idIMP,
			data:{idIMP},
			success: function(data) {
				$("#casosAbiertos").html(data);
			}
		});
		$.ajax({
			type: "GET",
			url: 'tablas/historico_Imp_casos_asoc2',
			idIMP:idIMP,
			data:{idIMP},
			success: function(data) {
				$("#casosResueltos").html(data);
			}
		});
		return false;
		
	  }
	}
	return ok;
  });
});
</script>
