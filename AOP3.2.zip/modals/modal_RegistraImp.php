<?php 
include_once('tipificaciones/ConsultasOperaciones.php');

  $query_NuevoCaso = "SELECT max(substr(substring_index(id_imp,'-',1),4))+1 AS idcaso FROM implementaciones;";
  $NuevoCaso = $Portal->query($query_NuevoCaso);
  $row_NuevoCaso = $NuevoCaso->fetch_assoc();
?>
<!-- Modal -->
<div class="modal fade" id="regIMP" tabindex="-1" role="dialog" data-backdrop="false" style="background-color:rgba(0,0,0,0.5);">
  <div class="modal-dialog" role="document">
	<div class="modal-content">
	  <div class="modal-header">
		<h5 class="modal-title col-11 text-center">Nueva Implementación</h5>
		<button type="button" class="close col-1" data-dismiss="modal" aria-label="Close">
		  <span aria-hidden="true">&times;</span>
		</button>
	  </div>
	  <div class="modal-body">
		<div class="container-fluid">
		<form role="form" id="formularioImp" class="needs-validation" method="get" novalidate>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="idIMP">IMP #</label>
			<div class="col-sm-9" id="divIdImp">
			  <input type="text" class="form-control form-control-sm" id="idIMP" name="idIMP" value="<?php echo "IMP".$row_NuevoCaso['idcaso']?>" required>
			  <div class="invalid-feedback">Campo obligatorio</div>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="motivoImplementa">Motivo</label>
			<div class="col-sm-9">
			  <select class="form-control form-control-sm" id="motivoImplementa" name="motivoImplementa" required><?php echo $Motivo_imp; ?></select>
			</div>
			<div class="invalid-feedback">Campo obligatorio</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="tipoImplementa">Tipo</label>
			<div class="col-sm-9">
			  <select class="form-control form-control-sm" id="tipoImplementa" name="tipoImplementa" required>
				<option value="" selected></option>
				<option value="Estandar">Estándar</option>
				<option value="Personalizada">Personalizada</option>
			  </select>
			</div>
			<div class="invalid-feedback">Campo obligatorio</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="cliente">Cliente</label>
			<div class="col-sm-9">
			  <select class="form-control form-control-sm" id="cliente" name="cliente" ><?php echo $Cliente; ?></select>
			</div>
			<div class="invalid-feedback">Campo obligatorio</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="prioridad">Prioridad</label>
			<div class="col-sm-9">
			  <select class="form-control form-control-sm" id="prioridad" name="prioridad" required><?php echo $Prioridad; ?></select>
			</div>
			<div class="invalid-feedback">Campo obligatorio</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="producto">Producto</label>
			<div class="col-sm-9">
			  <select class="form-control form-control-sm" id="producto" name="producto" required><?php echo $Producto; ?></select>
			</div>
			<div class="invalid-feedback">Campo obligatorio</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="medio">Escalado Por</label>
			<div class="col-sm-9">
			  <select class="form-control form-control-sm" id="medio" name="medio" required><?php echo $Medio_imp; ?></select>
			</div>
			<div class="invalid-feedback">Campo obligatorio</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="fechainicio">Fecha Imp</label>
			<div class="col-sm-9">
			  <input type="datetime-local" id="fechainicio" name="fechainicio" class="form-control form-control-sm" required>
			</div>
			<div class="invalid-feedback">Campo obligatorio</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="descripcion">Descripción</label>
			<div class="col-sm-9">
			  <textarea id="descripcion" name="descripcion" class="form-control form-control-sm" required></textarea>
			</div>
			<div class="invalid-feedback">Campo obligatorio</div>
		  </div>
		  <!--div class="form-group row">
			<label class="col-sm-3 col-form-label" for="clase">Clase</label>
			<div class="col-sm-9">
			  <select id="clase" name="clase" class="form-control form-control-sm" required><?php echo $Clase; ?></select>
			</div>
			<div class="invalid-feedback">Campo obligatorio</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label">Categoría</label>
			<div class="col-sm-9">
			  <select id="categoria" name="categoria" class="form-control form-control-sm" required>
				<option value=""></option>
			  </select>
			</div>
			<div class="invalid-feedback">Campo obligatorio</div>
		  </div-->
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="fechainicio">URL Soportes</label>
			<div class="col-sm-9">
			  <input type="text" class="form-control form-control-sm" id="urlImp" name="urlImp" placeholder="escriba url o no aplica" required>
			</div>
			<div class="invalid-feedback">Campo obligatorio</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="usuario_asignado">Asignado A</label>
			<div class="col-sm-9">
			  <select class="form-control form-control-sm" id="usuario_asignado" name="usuario_asignado" required><?php echo $Grupo; ?></select>
			</div>
			<div class="invalid-feedback">Campo obligatorio</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="aprueba_comite">Aprobó Comité</label>
			<div class="col-sm-9">
			  <div class="checkbox col-form-label">
				<label><input type="checkbox" style="width:17px;height:17px;" id="aprueba_comite" name="aprueba_comite" value="1"></label>
			  </div>
			</div>
		  </div>
		  <div class="ln_solid"></div>
		  <div class="modal-footer justify-content-between">
			<button type="reset" class="btn btn-default">Restablecer</button>
			<button id="Guardar" type="submit" class="btn btn-success">Registrar</button>
		  </div>
		  <input id="usuario_log" name="usuario_log" value="<?php echo $_SESSION['nombre'] . " " . $_SESSION['apellido']?>" hidden>
		</form>
		</div>
	  </div>
	</div>
  </div>
</div>
<script>
$.getScript("js/app/registra_Imp.js");
//$.getScript("tipificaciones/js/tipifica_caso.js");
</script>