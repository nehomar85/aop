<!-- Modal -->
<div class="modal fade" id="DetalleIMP" tabindex="-1" role="dialog" data-backdrop="false" style="background-color:rgba(0,0,0,0.5);">
  <div class="modal-dialog" role="document">
	<div class="modal-content">
	  <div class="modal-header">
		<h5 class="modal-title col-11 text-center">Detalle IMP</h5>
		<button type="button" class="close col-1" data-dismiss="modal" aria-label="Close">
		  <span aria-hidden="true">&times;</span>
		</button>
	  </div>
	  <div class="modal-body">
		<div class="container-fluid">
		<form role="form" id="formDetalleIMP" >
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="idcaso">IMP #</label>
			<div class="col-sm-9">
			  <input class="form-control form-control-sm" id="dIdIMP2" readonly>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="MotivoServicio">Motivo</label>
			<div class="col-sm-9">
			  <input class="form-control form-control-sm" id="dMotivoServicio2" readonly>
			</div>
		  </div>		  
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="TipoServicio">Tipo</label>
			<div class="col-sm-9">
			  <input class="form-control form-control-sm" id="dTipoServicio2" readonly>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="Cliente">Cliente</label>
			<div class="col-sm-9">
			  <input class="form-control form-control-sm" id="dCliente2" readonly>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="Prioridad">Prioridad</label>
			<div class="col-sm-9">
			  <input class="form-control form-control-sm" id="dPrioridad2" readonly>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="Producto">Producto</label>
			<div class="col-sm-9">
			  <input class="form-control form-control-sm" id="dProducto2" readonly>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="Medio">Escalado Por</label>
			<div class="col-sm-9">
			  <input class="form-control form-control-sm" id="dMedio2" readonly>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="FechaReporte">Fecha Imp</label>
			<div class="col-sm-9">
			  <input class="form-control form-control-sm" id="dFechaReporte2" readonly>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="Descripcion">Descripción</label>
			<div class="col-sm-9">
			  <Textarea class="form-control form-control-sm" id="dDescripcion2" readonly></Textarea>
			</div>
		  </div>
		  <!--div class="form-group row">
			<label class="col-sm-3 col-form-label" for="Clase">Clase</label>
			<div class="col-sm-9">
			  <input class="form-control form-control-sm" id="dClase2" readonly>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="Categoria">Categoría</label>
			<div class="col-sm-9">
			  <input class="form-control form-control-sm" id="dCategoria2" readonly>
			</div>
		  </div-->
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="URLIMP">URL Soportes</label>
			<div class="col-sm-9">
			  <input class="form-control form-control-sm" id="dURLIMP2" readonly>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="Grupo">Asignado A</label>
			<div class="col-sm-9">
			  <input class="form-control form-control-sm" id="dGrupo2" readonly>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="RegistroTrabajo">Registro de Trabajo</label>
			<div class="col-sm-9">
			  <Textarea class="form-control form-control-sm" id="dRegistroTrabajo2" readonly></Textarea>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="Estatus">Estatus</label>
			<div class="col-sm-9">
			  <input class="form-control form-control-sm" id="dEstatusIMP2" readonly>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="fechaSolucion">Fecha Solución</label>
			<div class="col-sm-9">
			  <input class="form-control form-control-sm" id="dFechaSolucion2" readonly>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label text-danger" for="horasTotal">Horas Total</label>
			<div class="col-sm-9">
			  <input class="form-control form-control-sm text-danger" id="dHorasTotal2" readonly>
			</div>
		  </div>
		  <div class="ln_solid"></div>
		  <div class="modal-footer justify-content-between">
			<button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
		  </div>
		</form>
		</div>
	  </div>
	</div>
  </div>
</div>