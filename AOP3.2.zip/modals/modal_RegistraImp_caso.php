<?php include_once('tipificaciones/ConsultasOperaciones.php');?>
<!-- Modal -->
<div class="modal fade" id="reg_IMPcaso" tabindex="-1" role="dialog" data-backdrop="false" style="background-color:rgba(0,0,0,0.5);">
  <div class="modal-dialog" role="document">
	<div class="modal-content">
	  <div class="modal-header">
		<h5 class="modal-title col-11 text-center">Nuevo Caso IMP</h5>
		<button type="button" class="close col-1" data-dismiss="modal" aria-label="Close">
		  <span aria-hidden="true">&times;</span>
		</button>
	  </div>
	  <div class="modal-body">
		<div class="container-fluid">
		<form role="form" id="formularioIMPcaso" method="post">
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="idIMPcaso">Caso-IMP #</label>
			<div class="col-sm-9" id="divIdImp">
			  <input type="text" class="form-control form-control-sm" id="idIMPcaso" name="idIMPcaso2" required>
			  <div class="invalid-feedback">Campo obligatorio</div>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="idIMP_asoc">IMP Asociada</label>
			<div class="col-sm-9" id="divIdImp">
			  <input type="text" class="form-control form-control-sm" id="idIMP_asoc" name="idIMP_asoc2" required readonly>
			  <div class="invalid-feedback">Campo obligatorio</div>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="fechaIMP">Registro IMP</label>
			<div class="col-sm-9" id="divIdImp">
			  <input type="text" class="form-control form-control-sm text-danger" id="fechaIMP" name="fechaIMP2" required readonly>
			  <div class="invalid-feedback">Campo obligatorio</div>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="clienteIMPcaso">Cliente</label>
			<div class="col-sm-9">
			  <input type="text" class="form-control form-control-sm" id="clienteIMPcaso" name="clienteIMPcaso2" required readonly>
			</div>
			<div class="invalid-feedback">Campo obligatorio</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="MotivoImplementaIMPcaso">Motivo</label>
			<div class="col-sm-9">
			  <select class="form-control form-control-sm" id="MotivoImplementaIMPcaso" name="MotivoImplementaIMPcaso2" required>
				<option value="" selected></option>
				<option value="Estabilizacion Incidente">Estabilización Incidente</option>
				<option value="Estabilizacion Solicitud">Estabilización Solicitud</option>
			  </select>
			</div>
			<div class="invalid-feedback">Campo obligatorio</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="prioridadIMPcaso">Prioridad</label>
			<div class="col-sm-9">
			  <select class="form-control form-control-sm" id="prioridadIMPcaso" name="prioridadIMPcaso2" required><?php echo $Prioridad; ?></select>
			</div>
			<div class="invalid-feedback">Campo obligatorio</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="medioIMPcaso">Escalado Por</label>
			<div class="col-sm-9">
			  <select class="form-control form-control-sm" id="medioIMPcaso" name="medioIMPcaso2" required><?php echo $Medio_imp; ?></select>
			</div>
			<div class="invalid-feedback">Campo obligatorio</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="fechainicioIMPcaso">Fecha Caso</label>
			<div class="col-sm-9">
			  <input type="datetime-local" id="fechainicioIMPcaso" name="fechainicioIMPcaso2" class="form-control form-control-sm" required>
			</div>
			<div class="invalid-feedback">Campo obligatorio</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="descripcionIMPcaso">Descripción</label>
			<div class="col-sm-9">
			  <textarea id="descripcionIMPcaso" name="descripcionIMPcaso2" class="form-control form-control-sm" required></textarea>
			</div>
			<div class="invalid-feedback">Campo obligatorio</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="clase">Clase</label>
			<div class="col-sm-9">
			  <select id="clase3" name="clase3" class="form-control form-control-sm" required><?php echo $Clase; ?></select>
			</div>
			<div class="invalid-feedback">Campo obligatorio</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label">Categoría</label>
			<div class="col-sm-9">
			  <select id="categoria3" name="categoria3" class="form-control form-control-sm" required>
				<option value=""></option>
			  </select>
			</div>
			<div class="invalid-feedback">Campo obligatorio</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="usuario_asignadoIMPcaso">Asignado A</label>
			<div class="col-sm-9">
			  <select class="form-control form-control-sm" id="usuario_asignadoIMPcaso" name="usuario_asignadoIMPcaso2" required><?php echo $Grupo; ?></select>
			</div>
			<div class="invalid-feedback">Campo obligatorio</div>
		  </div>
		  <div class="ln_solid"></div>
		  <div class="modal-footer justify-content-between">
			<button type="reset" class="btn btn-default">Restablecer</button>
			<button type="submit" class="btn btn-success" id="regIMP_caso">Registrar</button>
		  </div>
		  <input id="usuario_logIMPcaso" name="usuario_logIMPcaso2" value="<?php echo $_SESSION['nombre'] . " " . $_SESSION['apellido']?>" hidden>
		</form>
		</div>
	  </div>
	</div>
  </div>
</div>
<script>
$(document).ready(function(){
	$("#clase3").change(function(){
		$.ajax({
			url:"tipificaciones/TipificaCat_caso",
			type: "POST",
			data:"idclase="+$("#clase3").val(),
			success: function(clase){
				$("#categoria3").html(clase);
			}
		})
	});
});
</script>
<script>
$(document).ready(function() {
	$("#formularioIMPcaso").submit(function(e){
	var ok = true;
	var redir = 1;
	var CasoIMP = $("#idIMPcaso").val();
	var FechaIMP = $("#fechaIMP").val();
	var FechaIMPcaso = $("#fechainicioIMPcaso").val();
	
	if(Date.parse(FechaIMPcaso)<Date.parse(FechaIMP)){
	  msg = 'La Fecha del Caso debe ser mayor a la Fecha de Implementación';
	  redir = 0;
	  ok = false;	  
	}else{	  
	  e.preventDefault();
	  $.ajax( {
		url: "controllers/RegistrarImpCaso",
		method: "post",
		data: $("form").serialize(),
		dataType: "text",
		success: function(strMessage) {
		  //$("#message").text(strMessage);
		  //$("#formularioIMPcaso")[0].reset();
		}
	  });
	  msg = 'Caso '+CasoIMP+' Creado Correctamente';
	  redir = 1;
	  ok = false;
	}

	if(ok == false){
	  if(redir == 0){
		alert(msg);
	  }else{
		alert(msg);
		window.location.reload(true);
	  }
	}
	return ok;
	});
});
</script>