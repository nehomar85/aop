<?php include_once('tipificaciones/ConsultasOperaciones.php');?>
<!-- Modal -->
<div class="modal fade" id="editar" tabindex="-1" role="dialog" data-backdrop="false" style="background-color:rgba(0,0,0,0.5);">
  <div class="modal-dialog" role="document">
	<div class="modal-content">
	  <div class="modal-header">
		<h5 class="modal-title col-11 text-center">Actualizar IMP</h5>
		<button type="button" class="close col-1" data-dismiss="modal" aria-label="Close">
		  <span aria-hidden="true">&times;</span>
		</button>
	  </div>
	  <div class="modal-body">
		<div class="container-fluid">
		<form role="form" id="formModificaIMP" method="post">
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="idcaso">IMP #</label>
			<div class="col-sm-9">
			  <input class="form-control form-control-sm" id="eIdIMP2" name="eIdIMP2" readonly></input>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="MotivoServicio">Motivo</label>
			<div class="col-sm-9">
			  <select class="form-control form-control-sm" id="eMotivoServicio2" name="motivoServicio" required><?php echo $Motivo_imp; ?></select>
			</div>
		  </div>		  
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="TipoServicio">Tipo</label>
			<div class="col-sm-9">
			  <select class="form-control form-control-sm" id="eTipoServicio2" name="tipoServicio" required>
				<option value="" selected></option>
				<option value="Estandar">Estándar</option>
				<option value="Personalizada">Personalizada</option>
			  </select>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="Cliente">Cliente</label>
			<div class="col-sm-9">
			  <select class="form-control form-control-sm" id="eCliente2" name="cliente" ><?php echo $Cliente; ?></select>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="Prioridad">Prioridad</label>
			<div class="col-sm-9">
			  <select class="form-control form-control-sm" id="ePrioridad2" name="prioridad" required><?php echo $Prioridad; ?></select>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="Producto">Producto</label>
			<div class="col-sm-9">
			  <select class="form-control form-control-sm" id="eProducto2" name="producto" required><?php echo $Producto; ?></select>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="Medio">Escalado Por</label>
			<div class="col-sm-9">
			  <select class="form-control form-control-sm" id="eMedio2" name="medio" required><?php echo $Medio_imp; ?></select>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="FechaReporte">Fecha Imp</label>
			<div class="col-sm-9">
			  <input class="form-control form-control-sm" id="eFechaReporte2" name="fechaReporte" readonly></input>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="Descripcion">Descripción</label>
			<div class="col-sm-9">
			  <Textarea class="form-control form-control-sm" id="eDescripcion2" name="descripcion" required></Textarea>
			</div>
		  </div>
		  <!--div class="form-group row">
			<label class="col-sm-3 col-form-label" for="Clase">Clase</label>
			<div class="col-sm-9">
			  <select class="form-control form-control-sm" id="eClase2" name="clase" required><!?php echo $Clase; ?></select>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="Categoria">Categoría</label>
			<div class="col-sm-9">
			  <select class="form-control form-control-sm" id="eCategoria2" name="categoria" ><!?php echo $Categoria; ?></select>
			</div>
		  </div-->
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="URLIMP">URL Soportes</label>
			<div class="col-sm-9">
			  <input class="form-control form-control-sm" id="eURLIMP2" name="URLIMP" ></input>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="Grupo">Asignado A</label>
			<div class="col-sm-9">
			  <select class="form-control form-control-sm" id="eGrupo2" name="grupo" required><?php echo $Grupo; ?></select>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="RegistroTrabajo">Registro de Trabajo</label>
			<div class="col-sm-9">
			  <Textarea class="form-control form-control-sm" id="eRegistroTrabajo2" name="registroTrabajo" required></Textarea>
			</div>
		  </div>
		  <div class="form-group row">
			<label class="col-sm-3 col-form-label" for="Estatus">Estatus</label>
			<div class="col-sm-9">
			  <select class="form-control form-control-sm" id="eEstatusIMP2" name="eEstatusIMP2" onChange="validaEstadoIMP(this)" required><?php echo $Estatus_imp; ?></select>
			</div>
		  </div>
		  <div class="form-group row" style="">
			<label class="col-sm-3 col-form-label" for="casosAbiertos">Casos Abiertos</label>
			<div class="col-sm-9">
			  <input class="form-control form-control-sm text-danger" id="eCasosAbierto2" name="eCasosAbierto2" readonly ></input>
			</div>
		  </div>
		  <div class="form-group row" id="fechaLastUpd" style="display:none;">
			<label class="col-sm-3 col-form-label text-danger" for="fechaLastUpd">Último Update</label>
			<div class="col-sm-9">
			  <input class="form-control form-control-sm text-danger" id="eFechaLastUpd2" name="eFechaLastUpd2" readonly ></input>
			</div>
		  </div>
		  <div class="form-group row" id="fechaEstado" style="display:none;">
			<label class="col-sm-3 col-form-label" for="FechaEstado">Fecha Cambio</label>
			<div class="col-sm-9">
			  <input class="form-control form-control-sm" id="eFechaEstado2" type="datetime-local" name="eFechaEstado2" ></input>
			</div>
		  </div>
		  <div class="form-group row" id="fechaSolucion" style="display:none;">
			<label class="col-sm-3 col-form-label" for="FechaSolucion">Fecha Solución</label>
			<div class="col-sm-9">
			  <input class="form-control form-control-sm" id="eFechaSolucion2" type="datetime-local" name="eFechaSolucion2" ></input>
			</div>
		  </div>
		  <div class="ln_solid"></div>
		  <div class="modal-footer justify-content-between">
			<button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
			<button type="submit" class="btn btn-primary" id="regIMP">Actualizar</button>
		  </div>
		  <input id="usuario_log_IMP" name="usuario_log_IMP" value="<?php echo $_SESSION['nombre'] . " " . $_SESSION['apellido']?>" hidden>
		</form>
		</div>
	  </div>
	</div>
  </div>
</div>
<script>
//$.getScript("tipificaciones/js/tipifica_caso.js");
</script>
<script>
function validaEstadoIMP(sel) {
	divA = document.getElementById("fechaLastUpd");
	divB = document.getElementById("fechaEstado");
	divC = document.getElementById("fechaSolucion");
	
	if (sel.value=="Estabilizada" || sel.value=="Eliminada"){
		divA.style.display = "";
		divB.style.display = "";
		//divC.style.display = "";
	}else if (sel.value==""){
		divA.style.display="none";
		divB.style.display="none";
		//divC.style.display = "none";
	}else{
		divA.style.display = "";
		divB.style.display = "";
		//divC.style.display = "none";		
	}
}
</script>
<script>
$(document).ready(function() {
  $("#formModificaIMP").submit(function(e){
	var ok = true;
	var msg = '';
	var redir = 1;
	var idIMPupd = $("#eIdIMP2").val();
	var estatusIMP = $("#eEstatusIMP2").val();
	var fechaLastUpdIMP = $("#eFechaLastUpd2").val();
	var fechaEstadoIMP = $("#eFechaEstado2").val();
	var casosAbiertos = $("#eCasosAbierto2").val();
	//var fechaSolucionIMP = $("#eFechaSolucion2").val();
	
	if(estatusIMP == "Estabilizada" || estatusIMP == "Eliminada"){
		//CASOS ABIERTOS
		if(casosAbiertos==0){
			//COMPARA LAS FECHAS
			if(fechaEstadoIMP !== ""){
			  if(Date.parse(fechaEstadoIMP)<Date.parse(fechaLastUpdIMP)){
				msg = 'La Fecha de Cierre debe ser mayor al último update';
				redir = 0;
			  }else{
				e.preventDefault();
				$.ajax({
				  url: "controllers/ActualizarImp",
				  method: "post",
				  data: $("form").serialize(),
				  dataType: "text",
				  success: function(impUpd) {
				  	//Actualizada
				  }
				});
				msg = 'Implementación '+idIMPupd+' correctamente '+estatusIMP;
				redir = 1;
			  }
			}else{
			  msg = 'La Fecha de Cierre no puede estar en blanco';
			  redir = 0;
			}
		}else{
			msg = 'La Implementación '+idIMPupd+' tiene casos asociados Abiertos, deben ser cerrados antes de cambiar a '+estatusIMP;
			redir = 0;
		}
		ok = false;
	}else{
	  //if(fechaEstadoIMP !== ""){
		//COMPARA LAS FECHAS
		if(Date.parse(fechaEstadoIMP)<Date.parse(fechaLastUpdIMP)){
		  msg = 'La Fecha cambio de Estado debe ser mayor al último update';
		  redir = 0;
		}
		else{
		  e.preventDefault();
		  $.ajax({
		    url: "controllers/ActualizarImp",
		    method: "post",
		    data: $("form").serialize(),
		    dataType: "text",
		    success: function(impUpd) {
		 	  //Actualizada
		    }
		  });
		  msg = 'Implementación '+idIMPupd+' actualizada correctamente';
		  redir = 1;
		}
	  /*}
	  else{
		msg = "La Fecha de Solución no puede estar en blanco";
		redir = 0;
	  }*/
	  ok = false;
	}

	if(ok == false){
	  if(redir == 0){
		alert(msg);
	  }else{
		alert(msg);
		window.location.reload(true);
	  }
	}
	return ok;
  });
});
</script>